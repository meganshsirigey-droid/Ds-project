# FedGuard-MNIST: Secure and Robust Federated Learning with Malicious Client Detection

**A Three-Level Handwritten Digit Classification System**

CSC 8370 – Data Security  
Project Level 3: Robust Federated Learning with Attack Detection

**Authors:**  
Nanditha Kavuri (002858183)  
Meghansh Siregey (002894587)

**Department of Computer Science**  
**Wayne State University**

**November 2025**

---

## Abstract

This report presents FedGuard-MNIST, a comprehensive three-level handwritten digit classification system implemented in Python using PyTorch and convolutional neural network architectures. The system progresses from centralized learning (Level 1) through federated learning with simulated clients (Level 2) to robust federated learning with adversarial client detection (Level 3). The robust aggregation mechanism employs a trust-weighted approach that combines cosine similarity analysis with Local Outlier Factor (LOF) anomaly detection to identify and mitigate malicious client updates. Experimental evaluation on the MNIST dataset demonstrates that the system achieves 99.60% accuracy in centralized training, 98.80% accuracy under standard federated averaging, and maintains 97.66% accuracy while successfully detecting 100% of sign-flip attacks across all adversarial rounds. The implementation preserves 98.05% of baseline accuracy under attack, exceeding the project requirement of maintaining at least 95% baseline performance. All results are derived directly from executed code implementations with no assumptions beyond empirical observations.

---

## 1. Introduction

Federated learning has emerged as a promising paradigm for training machine learning models across distributed data sources without requiring raw data centralization. This approach addresses critical privacy concerns inherent in traditional centralized training, particularly in domains governed by regulations such as FERPA, HIPAA, and GDPR. However, the distributed nature of federated learning introduces new security vulnerabilities, as malicious participants can submit poisoned model updates that degrade global model performance or introduce backdoors.

The primary objective of this project is to design and implement a three-tier classification system that demonstrates both the effectiveness of federated learning and the necessity of robust aggregation mechanisms in adversarial environments. The system is constructed using a unified convolutional neural network architecture across all three levels, enabling direct performance comparisons while isolating the impact of different learning paradigms.

The first level establishes a centralized baseline, providing an upper bound for accuracy comparisons. The second level implements classical Federated Averaging (FedAvg) across multiple simulated clients, demonstrating the feasibility of distributed training. The third level extends the federated framework with a trust-weighted defense mechanism that detects and mitigates adversarial client behavior through multi-dimensional trust scoring.

This work contributes to the field of secure federated learning by demonstrating a practical defense mechanism that combines geometric similarity metrics with density-based anomaly detection. The implementation provides reproducible results, comprehensive logging, and transparent instrumentation suitable for academic evaluation and future research extensions.

---

## 2. Problem Statement and Threat Model

### 2.1 Problem Statement

The core problem addressed in this project is the design and implementation of a three-level MNIST handwritten digit classification system that satisfies the following requirements:

1. **Centralized Learning (Level 1):** Achieve high accuracy through standard supervised learning on a centralized dataset, establishing a performance baseline.

2. **Federated Learning (Level 2):** Distribute training across multiple simulated clients using Federated Averaging while maintaining accuracy comparable to the centralized approach.

3. **Robust Federated Learning (Level 3):** Extend the federated framework to detect and mitigate malicious client attacks while preserving model accuracy above 95% of the baseline performance.

The system must be fully reproducible, with all code, checkpoints, and detection statistics available for independent verification by teaching assistants and researchers.

### 2.2 Threat Model

The threat model follows a standard Byzantine fault tolerance framework adapted for federated learning scenarios. The system assumes:

**Honest Participants:**
- The central server is honest-but-curious: it faithfully executes aggregation algorithms but may analyze client updates for security purposes.
- Nine out of ten clients are honest and follow the prescribed training protocol.

**Adversarial Capabilities:**
- Exactly one client becomes adversarial after a configurable round (default: round 4).
- The malicious client has full knowledge of the global model received at the beginning of each round.
- The adversary can arbitrarily manipulate its outgoing model update without constraints.
- The attack persists for all subsequent rounds once activated.

**Attack Implementation:**
The implemented sign-flip attack generates malicious updates according to:

\[
w_{malicious} = -\alpha \cdot w_{global}
\]

where \(\alpha = 5.0\) represents a 500% scaling factor. This attack is particularly destructive because it creates updates that directly oppose the global model direction, causing cancellation effects when aggregated with honest updates using naive averaging.

**System Assumptions:**
- The attacker cannot compromise other clients' code or the server infrastructure.
- The attacker cannot prevent honest clients from participating.
- All clients maintain consistent participation (no dropouts).
- The server has access to all client updates before aggregation.

This threat model represents a realistic scenario in federated learning deployments where participants may have conflicting incentives or may be compromised by external attackers.

---

## 3. Related Work

Federated Averaging (FedAvg), introduced by McMahan et al. in 2017, established the foundational framework for federated learning by demonstrating that weighted averaging of client model updates can achieve performance comparable to centralized training. However, subsequent research revealed that FedAvg is highly vulnerable to Byzantine attacks, where malicious clients submit poisoned updates.

Early Byzantine-resilient aggregation methods focused on robust statistical techniques. Coordinate-wise median aggregation, proposed by Yin et al., computes the median of each parameter coordinate across clients, providing strong theoretical guarantees but potentially over-penalizing legitimate statistical variation. Trimmed mean methods remove extreme values before averaging, while Krum selects the update closest to a subset of other updates. Bulyan combines Krum with trimmed mean for additional robustness. These methods, while theoretically sound, often require assumptions about the maximum number of attackers and may exclude legitimate but diverse updates.

More recent research has explored trust-based and similarity-based defense mechanisms. FoolsGold uses gradient similarity to detect sybil attacks, while norm-bounding methods clip updates exceeding certain thresholds. Trust-weighted aggregation assigns dynamic weights to clients based on historical reliability or behavioral consistency.

Our approach aligns with this newer category of defenses by combining two complementary detection signals: cosine similarity captures directional alignment between client updates and the global model, while Local Outlier Factor (LOF) identifies statistical anomalies in the high-dimensional parameter space. This dual-metric approach provides broader attack coverage than either method alone, as it can detect both directional attacks (low cosine similarity) and magnitude-based attacks (high LOF scores).

The integration of LOF for federated learning security represents a novel application of density-based anomaly detection to the Byzantine-resilient aggregation problem, offering a complementary perspective to existing geometric and statistical methods.

---

## 4. System Overview and Architecture

The FedGuard-MNIST system is organized into three executable entry points, each implementing a distinct learning paradigm while sharing a common model architecture and utility infrastructure.

### 4.1 System Components

**Entry Points:**
- **`level1_main.py`:** Orchestrates centralized training with train/validation/test splits, learning rate scheduling, and best-model checkpointing based on validation accuracy.
- **`level2_main.py`:** Implements classical Federated Averaging across 10 IID clients, with per-round global model evaluation and checkpointing based on test accuracy.
- **`level3_main.py`:** Extends Level 2 with adversarial client simulation, trust-weighted aggregation, real-time attack detection logging, and comprehensive detection statistics.

**Shared Infrastructure:**
- **`models/mnist_cnn.py`:** Defines the SimpleCNN architecture used identically across all three levels, ensuring fair performance comparisons.
- **`utils/train_eval.py`:** Provides unified training and evaluation functions (`train_one_epoch`, `evaluate`) along with checkpoint management (`save_model`, `load_model`).
- **`utils/dataloader_adapter.py`:** Implements an adapter pattern that automatically detects and uses instructor-provided data loaders when available, otherwise falls back to torchvision MNIST with configurable IID partitioning for federated experiments.
- **`federated/fed_utils.py`:** Contains baseline federated learning utilities including `client_update` for honest client training and `fedavg_aggregate` for standard weighted averaging.
- **`federated/robust_fed_utils.py`:** Implements the robust aggregation mechanism with `client_update_malicious` for attack simulation, `compute_cosine_similarity` for geometric analysis, LOF-based anomaly detection, and `robust_aggregate` for trust-weighted aggregation.

### 4.2 Architecture Design Rationale

The modular architecture was designed to maximize code reuse while maintaining clear separation of concerns. By isolating data loading, model definition, training utilities, and aggregation logic into separate modules, the system achieves both maintainability and extensibility. The adapter pattern for data loading ensures compatibility with instructor-provided loaders while providing sensible defaults for independent execution.

All scripts implement comprehensive logging through structured print statements and progress bars (via `tqdm`), enabling transparent monitoring of training progress without requiring source code inspection. Checkpoints are saved to the `checkpoints/` directory with metadata including epoch/round numbers and accuracy values, facilitating model resumption and independent verification.

---

## 5. Methodology

### 5.1 Model Architecture

The SimpleCNN architecture was selected to balance expressive power with computational efficiency for MNIST-scale classification tasks. The architecture consists of three convolutional blocks followed by two fully connected layers, with a total of approximately 1.2 million trainable parameters.

**Convolutional Blocks:**
Each block follows the pattern: Convolution → Batch Normalization → ReLU → (optional second Convolution → Batch Normalization → ReLU) → Max Pooling → Dropout.

- **Block 1:** Two 3×3 convolutions (1→32 channels), max pooling (2×2), dropout (0.25)
- **Block 2:** Two 3×3 convolutions (32→64 channels), max pooling (2×2), dropout (0.25)
- **Block 3:** One 3×3 convolution (64→128 channels), max pooling (2×2), dropout (0.25)

**Fully Connected Layers:**
- **FC1:** 128×3×3 → 256 units with ReLU activation and dropout (0.5)
- **FC2:** 256 → 10 units (output logits for digit classes)

**Design Rationale:**
Batch normalization stabilizes training across clients with potentially different data distributions, which is particularly important in federated settings. Dropout provides implicit regularization, preventing overfitting when clients train on smaller data partitions. Max pooling reduces spatial dimensions progressively, keeping the parameter count manageable while preserving essential features. The architecture depth and width were chosen to achieve high accuracy without excessive computational overhead, making the system executable on both CPU and modest GPU hardware.

The consistent use of this architecture across all three levels ensures that observed performance differences can be attributed to learning paradigms rather than architectural variations, enabling meaningful comparative analysis.

### 5.2 Data Pipeline

The data loading infrastructure employs an adapter pattern that provides flexibility while maintaining reproducibility. When instructor-provided loaders (`dataloader4level1.py` or `dataloader4level2.py`) are present in the project root, the adapter automatically imports and uses them. Otherwise, the system falls back to torchvision MNIST with standard preprocessing.

**Data Preprocessing:**
- Normalization: Mean=0.1307, Std=0.3081 (canonical MNIST statistics)
- Transformation: Raw pixel values [0, 255] → Normalized tensors

**Data Splitting:**
- **Level 1:** 60,000 training samples split into 48,000 training and 12,000 validation; 10,000 test samples held out
- **Levels 2 & 3:** 60,000 training samples partitioned IID across 10 clients (6,000 samples each); 10,000 test samples shared globally

**IID Partitioning:**
For federated experiments, the training dataset is shuffled randomly, then divided into contiguous blocks assigned to clients. This IID (Independent and Identically Distributed) partitioning ensures each client receives a representative sample of all digit classes, isolating the impact of malicious behavior from non-IID data distribution effects.

**Optimization Settings:**
All data loaders use batch size 128, with `num_workers=4` (or 2 if fewer CPU cores available) and `pin_memory=True` when CUDA is available. These settings optimize data loading throughput, particularly important for federated experiments where multiple clients train concurrently.

### 5.3 Level 1 – Centralized Learning

The centralized learning implementation serves as the performance baseline and upper bound for federated comparisons. The training pipeline executes the following steps:

1. **Data Loading:** Load train/validation/test splits using the adapter
2. **Model Initialization:** Instantiate SimpleCNN and move to available device (CPU or GPU)
3. **Optimizer Configuration:** Adam optimizer with learning rate 0.001 and weight decay 5e-5
4. **Learning Rate Scheduling:** `ReduceLROnPlateau` with factor=0.5 and patience=5, monitoring validation accuracy
5. **Training Loop:** For 30 epochs:
   - Train on training set, compute training loss and accuracy
   - Validate on validation set, compute validation loss and accuracy
   - Update learning rate based on validation performance
   - Save checkpoint if validation accuracy improves
6. **Final Evaluation:** Load best validation model and evaluate on test set

**Optimizer Selection:**
Adam was chosen for centralized training due to its adaptive learning rate and fast convergence on image classification tasks. The weight decay parameter (5e-5) provides light regularization to prevent overfitting without significantly impacting learning dynamics.

**Learning Rate Scheduling:**
The `ReduceLROnPlateau` scheduler reduces the learning rate by half when validation accuracy plateaus for 5 consecutive epochs. This adaptive approach empirically reduced the number of epochs required to reach ≥99.5% accuracy compared to fixed learning rates.

**Checkpointing Strategy:**
The system saves the model with the highest validation accuracy, ensuring that transient improvements are preserved even if later epochs show slight fluctuations. This approach maximizes the likelihood of selecting the best-performing model for final evaluation.

The executed implementation achieved 99.60% test accuracy with a best validation accuracy of 99.53%, demonstrating that the architecture and hyperparameters are well-tuned before introducing federated constraints.

### 5.4 Level 2 – Federated Learning

Level 2 implements classical Federated Averaging (FedAvg) across 10 simulated clients, demonstrating the feasibility of distributed training without security considerations. The training pipeline operates as follows:

1. **Client Setup:** Partition training data IID across 10 clients, each receiving 6,000 samples
2. **Global Model Initialization:** Initialize SimpleCNN as the global model
3. **Federated Rounds:** For 30 rounds:
   - **Client Training:** Each client receives the current global model, performs 2 local epochs of SGD training, and returns updated parameters along with sample count
   - **Aggregation:** Server computes weighted average of client updates: \(w_{global} = \sum_{i} \frac{n_i}{N} \cdot w_i\), where \(n_i\) is client \(i\)'s sample count and \(N\) is total samples
   - **Evaluation:** Evaluate updated global model on shared test set
   - **Checkpointing:** Save model if test accuracy improves
4. **Final Evaluation:** Load best model and report final test accuracy

**Optimizer Selection:**
SGD with momentum (0.9) was chosen for federated training to align with FedAvg literature conventions and to simulate more communication-efficient optimization. The learning rate (0.001) and weight decay (5e-5) match Level 1 settings for consistency.

**Local Epochs:**
Two local epochs per client were selected based on empirical testing. This configuration balances client computation with communication frequency: too few epochs underutilize client data, while too many epochs increase communication overhead and may cause client drift. Pilot experiments showed diminishing returns beyond 2 local epochs while significantly extending total runtime.

**Aggregation Implementation:**
The `fedavg_aggregate` function in `federated/fed_utils.py` implements weighted averaging using vectorized operations. Client updates are stacked into tensors, weighted by normalized sample counts, and summed efficiently. This implementation avoids explicit loops over parameter keys, improving computational efficiency.

The system achieved 98.80% test accuracy, representing only a 0.80% drop from centralized performance. This minimal degradation demonstrates that federated learning can preserve most of the centralized accuracy when clients are honest and data is IID.

### 5.5 Level 3 – Robust Federated Learning Under Attack

Level 3 extends the Level 2 framework with adversarial client simulation and trust-weighted aggregation for attack detection and mitigation. The training pipeline mirrors Level 2 until client updates are collected, at which point robust aggregation is invoked.

**Adversarial Client Simulation:**
The malicious client (default: client 0) activates after a specified round (default: round 4). Instead of performing local training, it invokes `client_update_malicious`, which generates a poisoned update based on the attack type:

- **Sign-flip attack:** \(w_{malicious} = -5.0 \cdot w_{global}\)
- **Random attack:** \(w_{malicious} = \mathcal{N}(0, \sigma^2) \cdot 5.0\)
- **Scale attack:** \(w_{malicious} = 5.0 \cdot w_{global}\)
- **Zero attack:** \(w_{malicious} = \mathbf{0}\)

The default sign-flip attack with scale 5.0 was selected as it represents the most destructive attack that directly opposes the global model direction.

**Robust Aggregation Pipeline:**
The `robust_aggregate` function in `federated/robust_fed_utils.py` executes the following steps:

1. **Cosine Similarity Computation:**
   For each client update, compute cosine similarity with the global model:
   \[
   \text{cos\_sim}_i = \frac{w_i \cdot w_{global}}{||w_i|| \cdot ||w_{global}||}
   \]
   This metric captures directional alignment: honest updates should align with the global model, while sign-flip attacks produce negative or near-zero similarities.

2. **Local Outlier Factor Analysis:**
   Flatten all client updates into vectors and stack them into a 2D array. Apply `LocalOutlierFactor` from scikit-learn with `n_neighbors=min(5, num_clients-1)` and `contamination='auto'`. Convert negative outlier factors to positive scores and normalize to [0, 1] range. LOF identifies updates that are statistically rare in the parameter space, detecting attacks that may have reasonable cosine similarity but unusual magnitude or structure.

3. **Trust Score Calculation:**
   Combine normalized cosine similarity and LOF scores:
   \[
   \text{trust}_i = 0.6 \times \text{cos\_sim}_{normalized} + 0.4 \times \text{LOF}_{normalized}
   \]
   The weights (0.6 and 0.4) were chosen empirically to prioritize directional consistency (cosine) while still penalizing statistical anomalies (LOF). This dual-metric approach provides broader attack coverage than either metric alone.

4. **Malicious Client Detection:**
   Clients with trust scores below the detection threshold (default: 0.5) are flagged as malicious:
   \[
   \text{malicious} = \{i : \text{trust}_i < \theta\}
   \]
   Detected clients are logged and excluded from aggregation.

5. **Trust-Weighted Aggregation:**
   For honest clients, compute weighted average using both sample counts and trust scores:
   \[
   w_{new} = \frac{\sum_{i \notin \text{malicious}} n_i \times \text{trust}_i \times w_i}{\sum_{i \notin \text{malicious}} n_i \times \text{trust}_i}
   \]
   This approach ensures that highly trusted clients contribute more heavily to the global model, while suspicious but not definitively malicious clients can still contribute proportionally.

6. **Fallback Mechanism:**
   If all clients are flagged as malicious (edge case), the system resorts to coordinate-wise median aggregation to ensure training progress continues.

**Detection Statistics:**
The system tracks comprehensive detection metrics:
- Total rounds with active attacks
- Rounds where attacks were successfully detected
- Detection rate (detected_rounds / total_attack_rounds)
- False positives (honest clients incorrectly flagged)
- Final accuracy retention relative to baseline

Under the default attack configuration (sign-flip, scale 5.0, starting at round 4), the system achieved:
- 97.66% test accuracy (best checkpoint)
- 100% detection rate across all 7 attack rounds
- 17 false positives across 10 total rounds
- 98.05% accuracy retention relative to Level 1 baseline

These results demonstrate that the trust-weighted mechanism successfully identifies and mitigates adversarial updates while preserving model performance above the 95% baseline retention target.

---

## 6. Experimental Setup

All experiments were executed on a macOS system (Darwin 24.6.0) with Python 3.11 and PyTorch version ≥1.9.0. The MNIST dataset was automatically downloaded via torchvision on first execution. The following configuration parameters were consistent across all levels:

**Hardware Configuration:**
- Operating System: macOS (Darwin 24.6.0)
- Python Version: 3.11
- PyTorch Version: ≥1.9.0
- Device: CPU (CUDA unavailable on test system)

**Common Hyperparameters:**
- Batch Size: 128 for all data loaders
- Learning Rate: 0.001 (consistent across all levels)
- Weight Decay: 5e-5 (L2 regularization)
- Data Workers: 4 (or 2 if fewer CPU cores available)
- Pin Memory: Enabled when CUDA available

**Level-Specific Configuration:**

**Level 1:**
- Optimizer: Adam
- Epochs: 30
- Learning Rate Scheduler: ReduceLROnPlateau (factor=0.5, patience=5, mode='max')
- Validation Split: 20% of training data
- Training Duration: ~38.5 minutes

**Level 2:**
- Optimizer: SGD with momentum (0.9)
- Federated Rounds: 30
- Local Epochs per Client: 2
- Number of Clients: 10
- Training Duration: ~91 minutes

**Level 3:**
- Optimizer: SGD with momentum (0.9)
- Federated Rounds: 10
- Local Epochs per Client: 2
- Number of Clients: 10 (1 malicious)
- Malicious Client Index: 0
- Attack Start Round: 4
- Attack Type: sign_flip
- Attack Scale: 5.0
- Detection Threshold: 0.5
- Trust Weights: 60% cosine similarity, 40% LOF
- Training Duration: ~28.2 minutes

**Execution Commands:**
```bash
# Level 1
python level1_main.py --epochs 30 --batch_size 128 --lr 0.001

# Level 2
python level2_main.py --rounds 30 --num_clients 10 --local_epochs 2 --lr 0.001

# Level 3
python level3_main.py --rounds 10 --num_clients 10 --local_epochs 2 \
    --malicious_client 0 --malicious_start_round 4 \
    --attack_type sign_flip --attack_scale 5.0 --detection_threshold 0.5
```

**Logging and Instrumentation:**
All scripts implement comprehensive logging through:
- Structured print statements with timestamps and section headers
- TQDM progress bars for training and evaluation loops
- Per-epoch/round summaries with loss and accuracy metrics
- Detection statistics (Level 3) with real-time attack status
- Final summary tables with all key metrics

This instrumentation enables transparent monitoring of training progress and facilitates independent verification of results by teaching assistants.

---

## 7. Results and Discussion

### 7.1 Performance Summary

Table 1 presents the final accuracy results for all three levels of the system.

**Table 1: Final Test Accuracy Results**

| Level | Description | Best Test Accuracy | Training Configuration |
|-------|-------------|-------------------|----------------------|
| Level 1 | Centralized SimpleCNN | **99.60%** | 30 epochs, Adam optimizer, validation-based checkpointing |
| Level 2 | FedAvg with 10 IID clients | **98.80%** | 30 rounds, 2 local epochs, test-based checkpointing |
| Level 3 | Robust FL with sign-flip adversary | **97.66%** | 10 rounds, 100% attack detection rate |

### 7.2 Centralized vs Federated Performance

The transition from Level 1 to Level 2 results in a minimal accuracy degradation of 0.80%, demonstrating that federated learning can preserve the vast majority of centralized performance when clients are honest and data is IID. This small drop can be attributed to several factors:

1. **Statistical Aggregation Effects:** Weighted averaging of client models introduces slight approximation compared to centralized gradient descent.
2. **Client Drift:** Multiple local epochs per client may cause models to diverge slightly from the global optimum.
3. **Limited Communication Rounds:** 30 rounds may be insufficient to fully converge compared to 30 centralized epochs with access to all data.

Despite these factors, the 98.80% federated accuracy confirms that FedAvg is an effective aggregation strategy for IID data distributions.

### 7.3 Robustness Under Attack

Level 3 introduces adversarial clients and trust-weighted defense, resulting in an additional 1.14% accuracy drop relative to Level 2. However, the system maintains 97.66% accuracy, which represents 98.05% retention of the Level 1 baseline, exceeding the project requirement of maintaining at least 95% baseline performance.

**Table 2: Attack Detection Statistics (Level 3)**

| Metric | Value |
|--------|-------|
| Total rounds with attack | 7 (rounds 4-10) |
| Rounds where attack detected | 7 |
| Detection rate | **100.00%** |
| False positives | 17 total (≈1.7 per round) |
| Accuracy retention | 97.66% / 99.60% = **98.05%** |

The 100% detection rate demonstrates that the trust-weighted mechanism successfully identifies all sign-flip attacks. The 17 false positives indicate that the detection threshold (0.5) is appropriately conservative, prioritizing security over perfect precision. This trade-off is acceptable in security-critical applications where missing an attack is more costly than occasionally flagging honest clients.

### 7.4 Model Stability Analysis

Throughout Level 3 training, the global accuracy curve remained stable with no catastrophic drops after attacks commenced. This stability indicates that malicious updates were consistently filtered before aggregation, preventing gradient explosion, model collapse, or training divergence. The trust-weighted approach successfully isolated adversarial influence while preserving the contributions of honest clients.

### 7.5 Comparative Analysis

The performance progression from Level 1 (99.60%) to Level 2 (98.80%) to Level 3 (97.66%) demonstrates a gradual but controlled degradation that remains within acceptable bounds. The 1.94% total drop from centralized to robust federated learning represents a reasonable cost for the security benefits provided by the defense mechanism.

The system successfully balances three competing objectives:
1. **Accuracy:** Maintaining high classification performance
2. **Security:** Detecting and mitigating adversarial attacks
3. **Efficiency:** Minimizing computational and communication overhead

---

## 8. Security Analysis

### 8.1 Defense Mechanism Effectiveness

The trust-weighted aggregation mechanism employs multi-dimensional trust scoring to identify malicious clients:

**Cosine Similarity Component:**
Cosine similarity captures directional deviation between client updates and the global model. Sign-flip attacks produce negative or near-zero cosine similarities, making them easily detectable through this metric. The geometric interpretation is straightforward: honest clients train toward improving the global model, while malicious clients intentionally move in opposite directions.

**Local Outlier Factor Component:**
LOF provides complementary detection by identifying statistical anomalies in the high-dimensional parameter space. This density-based approach can detect attacks that may have reasonable cosine similarity but unusual magnitude, structure, or distribution. LOF is particularly effective at identifying coordinated attacks or sophisticated poisoning strategies that attempt to mimic honest update patterns.

**Trust Score Fusion:**
The weighted combination (60% cosine, 40% LOF) leverages the strengths of both metrics while mitigating their individual weaknesses. Cosine similarity excels at detecting directional attacks but may miss magnitude-based attacks. LOF excels at detecting statistical anomalies but may flag legitimate but diverse updates. The fusion provides broader attack coverage than either metric alone.

### 8.2 Attack Resistance

The implemented system successfully resists sign-flip attacks with 100% detection rate. The trust-weighted aggregation ensures that detected malicious clients are excluded from the global model update, preventing their adversarial influence from degrading model performance.

**Limitations:**
The current implementation assumes a single malicious client. While the trust framework is extensible to multiple attackers through threshold adjustment or contamination parameter tuning, empirical validation with multiple simultaneous attackers was not conducted in this project.

**False Positive Analysis:**
The 17 false positives observed across 10 rounds (approximately 1.7 per round) highlight the inherent precision-recall trade-off in security systems. Lower thresholds maximize attack detection (high recall) but increase false positive rates (lower precision). For production deployments, adaptive thresholds or secondary validation mechanisms could be employed to reduce false positives while maintaining high detection rates.

### 8.3 Threat Model Coverage

The implemented defense mechanism is effective against the sign-flip attack specified in the threat model. The system's ability to detect this attack with 100% accuracy demonstrates that the trust-weighted approach successfully addresses the primary security concern.

**Future Threat Considerations:**
More sophisticated attacks, such as adaptive attacks that attempt to evade detection by carefully crafting updates with moderate cosine similarity and normal LOF scores, may require additional defense layers. However, such attacks are beyond the scope of the current threat model and represent future research directions.

---

## 9. Conclusion and Future Work

This project successfully implements a three-level federated learning system that demonstrates both the effectiveness of distributed training and the necessity of robust aggregation mechanisms in adversarial environments. The system achieves 99.60% accuracy in centralized training, 98.80% under standard federated averaging, and maintains 97.66% accuracy while detecting 100% of sign-flip attacks.

The trust-weighted aggregation mechanism, combining cosine similarity with Local Outlier Factor analysis, provides a practical defense against Byzantine attacks while preserving model performance above the 95% baseline retention target. The implementation demonstrates that security and accuracy can be balanced effectively in federated learning systems.

**Future research directions include:**

1. **Adaptive Thresholding:** Develop dynamic detection thresholds that adjust based on training progress, historical trust scores, and observed attack patterns.

2. **Non-IID Data Distributions:** Evaluate robustness when clients possess skewed label distributions or heterogeneous data characteristics, which are common in real-world federated learning scenarios.

3. **Multiple Adversaries:** Extend the threat model to include multiple simultaneous malicious clients, potentially colluding to evade detection mechanisms.

4. **Advanced Attack Strategies:** Test defense effectiveness against sophisticated attacks such as gradient masking, backdoor injection, or adaptive evasion strategies.

5. **Scalability Analysis:** Evaluate system performance with larger client populations (100+ clients) and more complex datasets (Fashion-MNIST, CIFAR-10) to assess scalability.

6. **Visualization and Monitoring:** Develop real-time dashboards for trust scores, accuracy trends, and detection events to enhance system observability.

7. **Theoretical Analysis:** Provide formal guarantees on detection rates, false positive bounds, and convergence properties under various attack scenarios.

The codebase, documentation, and saved checkpoints provide a solid foundation for these future extensions and enable reproducible research in secure federated learning.

---

## 10. Learning Outcomes

### 10.1 Task Distribution

**Nanditha Kavuri (002858183):**
- Primary responsibility for Level 1 centralized learning implementation
- Model architecture design and optimization
- Data pipeline development and adapter pattern implementation
- Documentation and README creation

**Meghansh Siregey (002894587):**
- Primary responsibility for Level 2 and Level 3 federated learning implementation
- Trust-weighted aggregation mechanism design and implementation
- Attack simulation and detection logic development
- Experimental evaluation and results analysis

**Collaborative Efforts:**
- Joint code review and optimization
- Hyperparameter tuning and experimental design
- Report writing and documentation
- Testing and validation across all three levels

### 10.2 Challenges and Resolutions

**Challenge 1: Balancing Detection Sensitivity**
The initial detection threshold caused either too many false positives or missed attacks. Resolution: Empirical tuning through multiple experimental runs, selecting threshold 0.5 as optimal balance between security and precision.

**Challenge 2: Computational Efficiency**
LOF computation on high-dimensional parameter vectors was computationally expensive. Resolution: Optimized vector concatenation, batch processing, and efficient device memory management to reduce overhead.

**Challenge 3: Model Convergence Under Attack**
Initial implementations showed accuracy degradation when attacks commenced. Resolution: Implemented trust-weighted aggregation with proper fallback mechanisms, ensuring training stability even when all clients are flagged.

**Challenge 4: Code Organization and Maintainability**
Managing three levels with shared components required careful architecture. Resolution: Adopted modular design with clear separation of concerns, enabling code reuse while maintaining level-specific functionality.

**Challenge 5: Reproducibility and Verification**
Ensuring that results could be independently verified by teaching assistants. Resolution: Implemented comprehensive logging, automatic checkpointing, and detailed documentation of all hyperparameters and execution commands.

### 10.3 Lessons Learned

**Technical Insights:**
1. **Federated Learning Trade-offs:** The minimal accuracy drop (0.80%) from centralized to federated learning demonstrates that distributed training can be highly effective when data is IID and clients are honest.

2. **Security vs. Performance:** The 1.14% additional drop from federated to robust federated learning represents a reasonable cost for security benefits, confirming that defense mechanisms need not sacrifice significant accuracy.

3. **Multi-Metric Detection:** Combining cosine similarity with LOF provides broader attack coverage than either metric alone, demonstrating the value of complementary detection signals.

4. **Implementation Efficiency:** Careful optimization of aggregation operations, memory management, and data loading significantly impacts training time and resource utilization.

**Project Management Insights:**
1. **Modular Architecture:** Early investment in code organization and modular design paid dividends in development speed and maintainability.

2. **Incremental Development:** Building Level 1 first, then Level 2, then Level 3 enabled systematic validation and debugging at each stage.

3. **Comprehensive Logging:** Detailed logging and progress tracking were essential for debugging, optimization, and result verification.

4. **Documentation:** Maintaining up-to-date documentation throughout development facilitated collaboration and final report preparation.

**Research Insights:**
1. **Empirical Validation:** Theoretical security guarantees must be validated through empirical testing, as implementation details can significantly impact actual performance.

2. **Threshold Selection:** Detection thresholds require careful tuning based on specific attack characteristics and system requirements.

3. **False Positive Trade-offs:** Security systems must balance detection rates with false positive rates, requiring domain-specific considerations.

This project provided valuable experience in both federated learning implementation and security mechanism design, contributing to our understanding of distributed machine learning systems and their vulnerabilities.

---

## References

1. McMahan, B., Moore, E., Ramage, D., Hampson, S., & y Arcas, B. A. (2017). Communication-efficient learning of deep networks from decentralized data. *Proceedings of the 20th International Conference on Artificial Intelligence and Statistics (AISTATS)*, 1273-1282.

2. Yin, D., Chen, Y., Kannan, R., & Bartlett, P. (2018). Byzantine-robust distributed learning: Towards optimal statistical rates. *Proceedings of the 35th International Conference on Machine Learning (ICML)*, 5650-5659.

3. Breunig, M. M., Kriegel, H. P., Ng, R. T., & Sander, J. (2000). LOF: identifying density-based local outliers. *Proceedings of the 2000 ACM SIGMOD international conference on Management of data*, 93-104.

4. Kairouz, P., McMahan, H. B., Avent, B., Bellet, A., Bennis, M., Bhagoji, A. N., ... & Zhao, S. (2021). Advances and open problems in federated learning. *Foundations and Trends in Machine Learning*, 14(1-2), 1-210.

5. PyTorch Development Team. (2021). PyTorch Tutorials: Saving and Loading Models. Retrieved from https://pytorch.org/tutorials/beginner/saving_loading_models.html

6. LeCun, Y., Cortes, C., & Burges, C. J. (1998). The MNIST database of handwritten digits. Retrieved from http://yann.lecun.com/exdb/mnist/

---

## Appendix

### A. Code Overview

The project codebase is organized into the following modules:

**Entry Points:**
- `level1_main.py`: Centralized training script with validation-based checkpointing
- `level2_main.py`: Federated learning coordinator implementing FedAvg aggregation
- `level3_main.py`: Robust federated learning with adversarial client detection

**Model Definition:**
- `models/mnist_cnn.py`: SimpleCNN architecture definition with three convolutional blocks and two fully connected layers

**Federated Learning Utilities:**
- `federated/fed_utils.py`: Baseline client update function and FedAvg aggregation implementation
- `federated/robust_fed_utils.py`: Robust aggregation with trust-weighted mechanism, cosine similarity computation, LOF analysis, and malicious client update generation

**Shared Utilities:**
- `utils/train_eval.py`: Unified training and evaluation functions, checkpoint save/load utilities
- `utils/dataloader_adapter.py`: Data loading adapter with instructor loader support and torchvision fallback

**Configuration:**
- `requirements.txt`: Python package dependencies with version constraints
- `README.md`: Comprehensive project documentation
- `RUN_GUIDE.md`: Step-by-step execution instructions

**Checkpoints:**
- `checkpoints/level1_best_model.pth`: Best centralized model (99.60% accuracy)
- `checkpoints/level2_global_best_model.pth`: Best federated model (98.80% accuracy)
- `checkpoints/level3_robust_best_model.pth`: Best robust model (97.66% accuracy)

### B. Client Update Pseudocode

**Algorithm 1: Honest Client Update**

```
function CLIENT_UPDATE(global_model, train_loader, device, local_epochs, lr):
    // Initialize local model with global weights
    local_model ← copy(global_model)
    local_model.train()
    
    // Initialize optimizer
    optimizer ← SGD(local_model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-5)
    criterion ← CrossEntropyLoss()
    
    // Local training
    for epoch = 1 to local_epochs do
        for batch in train_loader do
            images, labels ← batch
            images, labels ← images.to(device), labels.to(device)
            
            optimizer.zero_grad()
            outputs ← local_model(images)
            loss ← criterion(outputs, labels)
            loss.backward()
            optimizer.step()
        end for
    end for
    
    num_samples ← len(train_loader.dataset)
    return local_model.state_dict(), num_samples
end function
```

**Algorithm 2: Malicious Client Update**

```
function CLIENT_UPDATE_MALICIOUS(global_model, attack_type, attack_scale):
    global_state ← global_model.state_dict()
    malicious_state ← {}
    
    if attack_type = "sign_flip" then
        for each key in global_state.keys() do
            malicious_state[key] ← -attack_scale × global_state[key]
        end for
    else if attack_type = "random" then
        for each key in global_state.keys() do
            malicious_state[key] ← RandomNormal(0, 1) × attack_scale
        end for
    else if attack_type = "scale" then
        for each key in global_state.keys() do
            malicious_state[key] ← attack_scale × global_state[key]
        end for
    else if attack_type = "zero" then
        for each key in global_state.keys() do
            malicious_state[key] ← zeros_like(global_state[key])
        end for
    end if
    
    return malicious_state, fake_sample_count
end function
```

### C. Detection Algorithm Pseudocode

**Algorithm 3: Trust-Weighted Robust Aggregation**

```
function ROBUST_AGGREGATE(global_model, client_updates, client_samples, threshold):
    num_clients ← length(client_updates)
    if num_clients = 0 then
        return global_model.state_dict(), []
    end if
    
    global_state ← global_model.state_dict()
    
    // Step 1: Compute cosine similarities
    cosine_similarities ← []
    for i = 1 to num_clients do
        vec_global ← flatten(global_state)
        vec_client ← flatten(client_updates[i])
        cos_sim ← dot(vec_global, vec_client) / (norm(vec_global) × norm(vec_client))
        cosine_similarities.append(cos_sim)
    end for
    
    // Step 2: Compute LOF scores
    update_vectors ← []
    for i = 1 to num_clients do
        update_vectors.append(flatten(client_updates[i]))
    end for
    
    n_neighbors ← min(5, max(2, num_clients - 1))
    lof ← LocalOutlierFactor(n_neighbors=n_neighbors, contamination='auto')
    lof_scores ← lof.fit_predict(update_vectors)
    lof_outlier_scores ← -lof.negative_outlier_factor_
    
    // Step 3: Normalize and combine trust scores
    cos_sim_normalized ← normalize(cosine_similarities)  // to [0, 1]
    lof_normalized ← 1.0 / (1.0 + lof_outlier_scores)    // invert and normalize
    
    trust_scores ← 0.6 × cos_sim_normalized + 0.4 × lof_normalized
    
    // Step 4: Detect malicious clients
    malicious_clients ← []
    for i = 1 to num_clients do
        if trust_scores[i] < threshold then
            malicious_clients.append(i)
        end if
    end for
    
    // Step 5: Trust-weighted aggregation
    honest_indices ← [i for i in 1..num_clients if i not in malicious_clients]
    honest_samples ← sum(client_samples[i] for i in honest_indices)
    
    if honest_samples = 0 then
        // Fallback: coordinate-wise median
        for each key in global_state.keys() do
            stacked ← stack([client_updates[i][key] for i in 1..num_clients])
            aggregated[key] ← median(stacked, dim=0)
        end for
        return aggregated, malicious_clients
    end if
    
    // Weighted average of honest clients
    aggregated_state ← {}
    for each key in global_state.keys() do
        total_weight ← 0.0
        weighted_sum ← zeros_like(global_state[key])
        
        for i in honest_indices do
            sample_weight ← client_samples[i] / honest_samples
            trust_weight ← trust_scores[i]
            weight ← sample_weight × trust_weight
            total_weight ← total_weight + weight
            weighted_sum ← weighted_sum + weight × client_updates[i][key]
        end for
        
        if total_weight > 0 then
            aggregated_state[key] ← weighted_sum / total_weight
        else
            aggregated_state[key] ← global_state[key]  // no update
        end if
    end for
    
    return aggregated_state, malicious_clients
end function
```

This pseudocode accurately reflects the implementation in `federated/robust_fed_utils.py` and produces the observed detection behavior and accuracy metrics reported in Section 7.

---

**End of Report**

*Project Completion Date: November 25, 2025*  
*Total Pages: 10*  
*Word Count: ~4,200*
