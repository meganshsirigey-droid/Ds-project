"""Federated learning package"""

